# Legal Help India — GitHub वर अपडेट करण्याची सोपी पद्धत

ही ZIP आधीच्या Claude ने तयार केलेल्या `site.zip` ची **production-style upgrade** आहे. Existing legal content, Google Apps Script backend, forms, PDF generator आणि PWA structure जपले आहेत.

## 1) GitHub मध्ये काय करायचे?
1. तुमचे आधीचे repository उघडा.
2. या ZIP मधील **सगळ्या फाईल्स/फोल्डर्स** repository च्या root मध्ये upload करा.
3. GitHub ने `Replace files` विचारल्यास **Replace/Overwrite** करा.
4. विशेषतः खालील फाईल्स overwrite झाल्या आहेत: `index.html`, `app.js`, `manifest.json`, `sw.js`, `shared/ui.css`, `shared/config.js`, `admin/index.html`, `admin/style.css`, `admin/manifest.json`, `admin/sw.js`.
5. नवीन `brand/` folder आणि `admin/icons/` folder पूर्ण upload करा.
6. GitHub → **Settings → Pages** मध्ये branch `main` आणि folder `/ (root)` निवडा.
7. Save केल्यानंतर काही मिनिटांनी site उघडा.

## 2) कोणती फाईल काय करते?
| फाईल | काम |
|---|---|
| `index.html` | User PWA चे मुख्य UI |
| `app.js` | User app चे interactions/API calls |
| `shared/content.js` | कायदे/संविधान/भाषा content |
| `shared/ui.css` | User + Admin चे professional design system |
| `shared/config.js` | API URL, WhatsApp, email, brand settings |
| `manifest.json` | User PWA install metadata |
| `sw.js` | User offline/cache service worker |
| `brand/user-logo-hd.png` | नवीन User high-resolution logo |
| `admin/index.html` | Admin PWA UI |
| `admin/app.js` | Admin dashboard logic |
| `admin/style.css` | Admin-specific styling |
| `admin/manifest.json` | Admin PWA install metadata |
| `admin/sw.js` | Admin cache/service worker |
| `brand/admin-logo-hd.png` | नवीन Admin high-resolution logo |
| `backend/Code.gs` | Google Apps Script backend |
| `CLAUDE_PROMPT_PRO.md` | पुढील development साठी Claude instructions |

## 3) User आणि Admin कुठे उघडतील?
- User: `https://YOUR-USERNAME.github.io/YOUR-REPO/`
- Admin: `https://YOUR-USERNAME.github.io/YOUR-REPO/admin/`

## 4) API/WhatsApp बदलायचे असल्यास
फक्त `shared/config.js` मध्ये settings बदलायच्या. API URL मध्ये बदल करण्यापूर्वी Google Apps Script deployment तपासा.

## 5) Logo बदलायचा असल्यास
- User logo: `brand/user-logo-hd.png` / `brand/user-logo.png`
- Admin logo: `brand/admin-logo-hd.png` / `brand/admin-logo.png`
- PWA icons: `icons/` आणि `admin/icons/`

## 6) महत्त्वाची production सूचना
Admin password/frontend session ही पूर्ण security system नाही. Real production deployment मध्ये server-side authentication, authorization, HTTPS आणि role-based access control वापरा.
