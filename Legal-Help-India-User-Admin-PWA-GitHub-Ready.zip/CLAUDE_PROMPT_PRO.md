# Claude AI — Legal Help India Professional PWA Upgrade Prompt

You are working on the existing **Legal Help India** single-repository PWA. Do not remove or rewrite the existing legal/Constitution content unless explicitly asked.

## Product
Build and maintain two polished PWAs from the same repository:
- User: `/`
- Admin: `/admin/`

## Branding
Use the supplied assets:
- `brand/user-logo-hd.png` for User branding
- `brand/admin-logo-hd.png` for Admin branding
- Do not invent a different logo or brand palette.

## Visual direction
Premium Indian legal-service aesthetic: navy, restrained gold, subtle saffron/green accents, white cards, strong typography, clean spacing, responsive mobile-first UI. Keep it simple, trustworthy and professional.

## Preserve
- `shared/content.js` legal content
- `shared/pdf.js` PDF generation
- Google Apps Script API integration in `shared/config.js`
- User forms, request tracking, reviews, multilingual UI
- Admin dashboard functionality
- PWA service workers and manifests

## Improve safely
- Accessibility labels and keyboard navigation
- Loading/error/empty states
- Responsive layouts
- PWA installability
- Cache versioning when assets change
- Never expose private backend secrets in frontend files
- Never hard-code an admin password into a public JavaScript file

## Before editing
1. Inspect existing files.
2. Reuse existing logic rather than duplicating it.
3. Keep the repository deployable from GitHub Pages.
4. Explain every changed file in the final response.
