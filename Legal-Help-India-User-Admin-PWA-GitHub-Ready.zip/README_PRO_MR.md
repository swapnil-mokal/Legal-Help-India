# Legal Help India — Professional User + Admin PWA

ही package तुमच्या आधीच्या `site.zip` वर आधारित आहे. नवीन User आणि Admin logos वापरून UI/branding upgrade केले आहे.

### GitHub upload
`GITHUB-UPLOAD-GUIDE-MR.md` वाचा आणि ZIP मधील सर्व files repository root मध्ये upload करून existing files overwrite करा.

### URLs
- User: repository root
- Admin: `/admin/`

### Existing backend
`shared/config.js` मधील विद्यमान API URL/contact settings जतन केले आहेत.

### Important
Frontend-only admin authentication ला पूर्ण production security समजू नका. Production मध्ये server-side authentication आवश्यक आहे.
