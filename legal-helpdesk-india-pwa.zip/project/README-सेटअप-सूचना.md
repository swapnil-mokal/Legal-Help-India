# Legal Helpdesk India — PWA सेटअप सूचना

तुमचं अ‍ॅप आता एक पूर्ण **PWA (Progressive Web App)** बनवलं आहे. खाली नक्की काय
बदललं / जोडलं गेलं आणि लाईव्ह करण्यासाठी काय करायचं ते दिलं आहे.

---

## १. काय नवीन जोडलं गेलं?

| भाग | तपशील |
|---|---|
| **PWA** | `manifest.json`, `sw.js` (service worker), `icons/` फोल्डर जोडला. आता फोन/लॅपटॉपवर "Install App" करता येईल आणि इंटरनेटशिवायही ऍप शेल उघडेल. |
| **Install बटण** | होमपेजवर तळाशी एक "इन्स्टॉल करा" पट्टी (bar) आपोआप दिसेल (Chrome/Edge/Android वर). |
| **संपर्क क्रमांक** | सर्वत्र **+91 98700 20674** असा अपडेट केला (आधी वेगळा नंबर होता). |
| **ईमेल** | संपर्क पानावर आता स्पष्ट **sbm.group.legalservices@gmail.com** दाखवला व ईमेल बटण जोडलं. फॉर्म भरल्यावर येणारा mailto लिंकसुद्धा हाच ईमेल वापरतो. |
| **Google Drive मध्ये Excel (Google Sheet)** | प्रत्येक नवीन "कायदेशीर मदत विनंती" आणि "पुनरावलोकन" आता आपोआप तुमच्या Google Drive मधील एका Google Sheet मध्ये (Excel सारखी) रांगेत (row) साठवली जाईल — पूर्णपणे मोफत. सेटअप खाली दिलं आहे. |
| **AI प्रश्नोत्तर, संविधान कलमे, भाषा (मराठी/हिंदी/इंग्रजी)** | हे आधीच तुमच्या फाईल्समध्ये तयार होतं — त्यात काही बदल केलेला नाही, फक्त तपासून खात्री केली. |

---

## २. फाईल स्ट्रक्चर (Netlify वर अपलोड करताना अशीच ठेवा)

```
/ (root)
 ├─ index.html
 ├─ admin.html
 ├─ manifest.json          ← नवीन
 ├─ sw.js                  ← नवीन
 ├─ netlify.toml
 ├─ icons/                 ← नवीन
 │   ├─ icon-192.png
 │   ├─ icon-192-maskable.png
 │   ├─ icon-512.png
 │   └─ icon-512-maskable.png
 ├─ functions/
 │   ├─ ask.js
 │   ├─ submit-legal-help.js     ← अपडेट (Google Sheet backup जोडलं)
 │   ├─ submit-review.js         ← अपडेट (Google Sheet backup जोडलं)
 │   ├─ review-action.js
 │   ├─ reviews.js
 │   ├─ admin-legal-requests.js
 │   ├─ admin-reviews.js
 │   └─ lib/
 │       ├─ jsonbin.js
 │       └─ googleSheet.js       ← नवीन
 └─ google-apps-script/
     └─ Code.gs            ← हे Netlify वर नाही, Google Sheet मध्ये टाकायचं (पायरी ३ बघा)
```

> `netlify.toml` मध्ये आधीच `functions = "functions"` आणि `publish = "."` सेट आहे, त्यामुळे वरची रचना तशीच ठेवा.

---

## ३. Google Drive मध्ये Excel Sheet ऑटो-सेव्ह सेटअप (एकदाच करायचं)

1. https://sheets.google.com वर नवीन रिकामी Sheet तयार करा — नाव द्या उदा. **"Legal Helpdesk India - Data"**.
2. मेनूमध्ये **Extensions → Apps Script** वर क्लिक करा.
3. जुना कोड डिलीट करून `google-apps-script/Code.gs` मधला संपूर्ण कोड कॉपी-पेस्ट करा. Save करा.
4. वरती उजवीकडे **Deploy → New deployment**.
   - Type: **Web app**
   - Execute as: **Me**
   - Who has access: **Anyone**
   - **Deploy** दाबा, गरज पडल्यास तुमच्या Google खात्याला परवानगी द्या.
5. मिळालेला **Web app URL** कॉपी करा (उदा. `https://script.google.com/macros/s/XXXX/exec`).
6. Netlify डॅशबोर्डवर तुमच्या साईटच्या **Site configuration → Environment variables** मध्ये नवीन variable जोडा:
   - Key: `GOOGLE_SHEET_WEBHOOK_URL`
   - Value: वरचा URL
7. **Trigger deploy → Clear cache and deploy site** करा.

झालं! आता प्रत्येक फॉर्म सबमिशन त्या Google Sheet मध्ये आपोआप जमा होईल, आणि केव्हाही
**File → Download → Microsoft Excel (.xlsx)** करून Excel फाईल काढता येईल. Admin पॅनलमधलं
"Excel डाउनलोड" बटणही आहेच तसंच — दोन्ही पर्याय उपलब्ध राहतील.

---

## ४. Netlify वर आवश्यक Environment Variables (एकूण यादी)

| Key | कशासाठी | आधीपासून आहे की नवीन |
|---|---|---|
| `GROQ_API_KEY` | AI प्रश्नोत्तरासाठी (Groq, मोफत) | आधीपासून आहे |
| `JSONBIN_BIN_ID` | डेटा साठवण्यासाठी (jsonbin.io, मोफत) | आधीपासून आहे |
| `JSONBIN_API_KEY` | वरील प्रमाणे | आधीपासून आहे |
| `ADMIN_PASSWORD` | Admin पॅनल लॉगिनसाठी | आधीपासून आहे |
| `GOOGLE_SHEET_WEBHOOK_URL` | Google Sheet मध्ये ऑटो-बॅकअपसाठी | **नवीन — वर दिल्याप्रमाणे सेट करा** |

---

## ५. लाईव्ह टेस्ट कशी करायची?

1. साईट डिप्लॉय झाल्यावर मोबाईलवर Chrome मध्ये उघडा — काही सेकंदात तळाशी "इन्स्टॉल करा" पट्टी दिसेल. दाबल्यावर ऍप होम स्क्रीनवर इन्स्टॉल होईल (App Store/Play Store शिवाय, पूर्णपणे मोफत).
2. "कायदेशीर मदत मागवा" फॉर्म भरून टेस्ट सबमिट करा → Admin पॅनलमध्ये दिसेल का बघा → Google Sheet मध्येही नवीन row आली का बघा.
3. "प्रश्न विचारा" (AI) मध्ये एक प्रश्न विचारून उत्तर मिळतंय का तपासा.
4. संपर्क पानावर नंबर व ईमेल बरोबर दिसतायत का तपासा (📞 +91 98700 20674, ✉ sbm.group.legalservices@gmail.com).

---

## ६. हे कायमचं मोफत (Lifetime Free) कसं आहे?

- **Netlify** — वैयक्तिक/छोट्या साईटसाठी Free tier कायमचा मोफत.
- **JSONBin.io** — छोट्या डेटासाठी Free tier मोफत.
- **Groq API** — सध्या मोफत टियर उपलब्ध (AI उत्तरांसाठी).
- **Google Sheets + Apps Script** — Google च्या वैयक्तिक खात्यासाठी कायमचं मोफत.
- **PWA (manifest + service worker)** — कोणतंही App Store शुल्क नाही, वेबसाईटवरूनच इन्स्टॉल होतं.

यापैकी कशाचंही कधी बिल येत नाही, फक्त प्रत्येक सेवेच्या मोफत मर्यादेत (free-tier limits)
वापर राहील याची काळजी घ्या (सामान्य वापरासाठी या मर्यादा भरपूर आहेत).
